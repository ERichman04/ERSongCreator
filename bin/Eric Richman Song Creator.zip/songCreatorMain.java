import org.jfugue.pattern.Pattern;
import org.jfugue.player.Player;
import org.jfugue.rhythm.Rhythm;
import org.jfugue.theory.ChordProgression;
public class songCreatorMain {

	public static void main(String[] args) {
		songGUI song = new songGUI();
		}
}
